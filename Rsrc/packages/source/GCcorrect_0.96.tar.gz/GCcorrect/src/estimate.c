/*
 *  surfEst.c
 *  surfEst
 *
 *  Created by Yuval Benjamini on 11/8/10.
 *  Copyright 2010 UC Berkeley. All rights reserved.
 *
 */
#include <R.h>
#include <stdio.h>
#define MAXLEN 700
#define FASTCNT_MAXVAL 2001

void surfE (int *c,const int *num) {
  if (num[0] < 10) {
    c[num[0]] =1 ;
  }
  Rprintf("c[num] %d %d",num[0],c[num[0]]);
	// insert code here...
}

void countersPrint(int *count, int minlen, int maxlen){
  int i;
  for (i = minlen; i<= maxlen; i++){
    Rprintf("%d:%d ",i, count[i]);
  }
  Rprintf("\n");
}


void makeFullTable(int *nlocs, int *nfrag, // outputs
		   int *gcline,int *gclen, //
		   int *locs,int *lengs, int *loclenglen, int *sampline, // inputs
		   int *minlens,int *maxlens, int *margin,int *max_frag_for_loc // params
		   ) {
  //lenses = minlens:maxlens

  Rprintf("%d %d %d",margin[0],minlens[0],maxlens[0]);
  int counters[MAXLEN];

  // Intialize counters to 0
  int i,j,l;
  for (i=0; i< MAXLEN; i++){
    for (j=0; j< MAXLEN; j++){
      nlocs[i+j*MAXLEN] = 0;
      nfrag[i+j*MAXLEN] = 0;
    }
    counters[i] = 0;
  }

  // Initialize counters, for location 300:
  const int init_loc = 300;

  int tmp_sum = 0;
  for (i=margin[0]; i<=maxlens[0]-margin[0] ; i++){
    tmp_sum = tmp_sum + gcline[i+init_loc];
    if (i+margin[0] >= minlens[0]) {
      counters[i+margin[0]] = tmp_sum;
    }
  }

  //countersPrint(counters,minlens[0], maxlens[0]);

  // loc marks location (of begining of fragment) in chromosome     
  int loc = init_loc+1;
  int f_ind = 0;
  // f_ind marks indicator of first fagment starting at i in the locs_and_leng list
  int cnt=0;
  int chrom_edge = 1000;
  while( (loc+chrom_edge < locs[loclenglen[0]-1]) && (loc+chrom_edge < gclen[0])) {

    // Update counters
    for (i=minlens[0]; i<=maxlens[0] ; i++){
      counters[i] = counters[i] - gcline[loc+margin[0]-1] + gcline[loc+ i - margin[0]-1];

      if ((counters[i]<0) || (counters[i]>i) ) {
	Rprintf("Error, i:%d, counters[i]:%d, loc: %d, f_ind: %d \n",i, counters[i], loc, f_ind );
	return;
      }

    }
    // Move the fragment indicator
    while(( locs[f_ind] < loc) && (f_ind<loclenglen[0]-1)) {
      f_ind= f_ind+1;
    }
    // If this is a sample point, add to both nlocs and to nfrags
    if (sampline[loc-1]) {
      // for each fragment length add the gc into the location counts
      for (i=minlens[0]; i<=maxlens[0] ; i++){
        nlocs[ i + MAXLEN*counters[i]] = nlocs[i + MAXLEN*counters[i]] + 1;
      }
      // Now count how many fragments exist of this length
      for (j = f_ind; (j<loclenglen[0]-1) && (locs[j]==loc); j++){
	l = lengs[j];
	if ( (l<= maxlens[0]) && (l>= minlens[0])) {
          nfrag[l+ MAXLEN*counters[l]] = nfrag[l+MAXLEN*counters[l]] + 1;
	  cnt++;
	  
	  //if (l == 400){
	  //  printf("FragInd %d, Loc %d, Frag %d, GC %d\n",j,loc,cnt, counters[l]);
	  //} 
        }
	
      }
    }
    // some output that we are making progress
    if ((loc % 1000000) == 0){
      Rprintf(".");
      //      Rprintf("%d, %d, %d, %d, %d, %d, %d\n", cnt, loc, f_ind, locs[f_ind],lengs[f_ind], nfrag[600*600-1], nlocs[600*600-1]);

    }
    loc = loc + 1;
  }
  Rprintf("Total Fragments: %d, Final", cnt);
}

void binReads(int *binres, const int *binfield, const int *binfieldlen,const int *binsize) {
  // Bins a set of locations (such as read locations)
  int i; 
  for (i = 0; i< binfieldlen[0]; i++){
    binres[binfield[i]/binsize[0]] ++;
  }
}

void sumLine(int *binres, const int *binfield, const int *binfieldlen,const int *binsize) {
  // Bins a continuous field (such as gc, map)
  int i; 
  for (i = 0; i< binfieldlen[0]; i++){
    binres[i/binsize[0]] += binfield[i];
  }
}

void sumLineDouble(double *binres, const double *binfield, const int *binfieldlen,const int *binsize) {
  // Bins a continuous field (such as gc, map)
  int i; 
  for (i = 0; i< binfieldlen[0]; i++){
    binres[i/binsize[0]] += binfield[i];
  }
}


void sampleLine(int *sline, const int* reads,const int* maxpos, const int* readslen) {
  int i;
  for (i=0; i<readslen[0]; i++) {
    if (reads[i]-1>maxpos[0]){ 
      // Reached reads outside region of interest
      break;
    }
    // reads[i]-1 adjust for R-indexing starting at 1
    sline[reads[i]-1]++;
  }
}

void genOverlapLine(const int *oline, int *nline, const int * linelen, const int* shifts, const int* n_shifts) {
  // NA's are negative numbers 
  int i,s; 
  for (s = 0; s<n_shifts[0]; s++) {
    Rprintf(".");
    for (i=0; i<linelen[0]; i++) {
      if ((i + shifts[s] >= 0 ) && (i + shifts[s] < linelen[0] )) {
	if (oline[i+shifts[s]] < 0){
	  nline[i] = -n_shifts[0]; // This means it is NA
	}
	else{
	  nline[i] += oline[i+shifts[s]];
	}
      }
      else{
	nline[i] = -n_shifts[0];
      }
    }
  }
  Rprintf("\n");
}

// For make-GC when this is a window
void runAverage(const int *oline, int *nline, const int * linelen, const int* winsize) { 
   // NA's are negative numbers  
  
   // First Pass - Assume no NAs 
   int count = 0; 
   int l,i;
   for(l=0; l < winsize[0]; l++) {
     count += oline[l];
   }
   nline[0] = count;

   for (i=1; (i-1+ winsize[0]) <linelen[0]; i++) { 
     count = count + oline[i-1 + winsize[0]] - oline[i-1]; 
     nline[i] = count; 

     
   }

   for (i= linelen[0]-winsize[0]+1 ; i<linelen[0] ; i++) {
     nline[i] = -1;
   }

   // Second Pass - Add NAs. 
   for (i=linelen[0]-1; i >= 0 ; i--) { 
     if (oline[i]<0) { 
       l = winsize[0];
     } else {
       if (l>0) {
	 l -= 1; 
       } 
     }
     if (l>0) {
       nline[i] = -1;
     }
   }
} 

void genOverlapLineReal(const double *oline, double *nline, const int * linelen, const int* shifts, const int* n_shifts) {
  // No NA's allowed
  int i,s; 
  for (s = 0; s<n_shifts[0]; s++) {
    Rprintf(".");
    if (shifts[s]==0) {
      continue;
    }
    for (i=0; i<linelen[0]; i++) {
      if ((i + shifts[s] >= 0 ) && (i + shifts[s] < linelen[0] )) {
	nline[i] += oline[i+shifts[s]];
      }
      else{
	nline[i] = 0.0;
      }
    }
  }
}


void getFullTablePreds(double *predictions,const int *beg,const int *length, 
		       const double *predTable, const int *minlens,int *maxlens,
		       const int *gcline,const int *gclen, int *margin ) {
  //lenses = minlens:maxlens

  Rprintf("%d %d %d",margin[0],minlens[0],maxlens[0]);
  int counters[MAXLEN];
  // Intialize counters to 0
  int i,j,l;
  for (i=0; i< MAXLEN; i++){
    counters[i] = 0;
  }


  // Initialize counters, for location 300:
  const int init_loc = 300;

  int tmp_sum = 0;
  for (i=margin[0]; i<=maxlens[0]-margin[0] ; i++){
    tmp_sum = tmp_sum + gcline[i+init_loc];
    if (i+margin[0] >= minlens[0]) {
      counters[i+margin[0]] = tmp_sum;
    }
  }


  // loc marks location (of begining of fragment) in chromosome     
  int loc = init_loc+1;
  int f_ind = 0;
  // f_ind marks indicator of first fagment starting at i in the locs_and_leng list
  int cnt=0;
  int chrom_edge = 1000;
  while( (loc+chrom_edge < gclen[0]) && (loc+chrom_edge < beg[0] + length[0] - 1)) {

    // Update counters
    for (i=minlens[0]; i<=maxlens[0] ; i++){
      counters[i] = counters[i] - gcline[loc+margin[0]-1] + gcline[loc+ i - margin[0]-1];

      if ((counters[i]<0) || (counters[i]>i) ) {
	Rprintf("Error, i:%d, counters[i]:%d, loc: %d, f_ind: %d \n",i, counters[i], loc, f_ind );
	return;
      }

      if(loc >= beg[0]){
	predictions[loc - beg[0]] += predTable[i + MAXLEN*counters[i]];
      }
    }
    if ((loc % 1000000) == 0){
      //  Rprintf("%d, %d, %d, %d, %d, %d, %d\n", cnt, loc, f_ind, fragments[f_ind],j, nfrag[MAXLEN*MAXLEN-1], nlocs[MAXLEN*MAXLEN-1]);
      Rprintf(".");
    }   
  loc = loc + 1;

  }
}

  
void makeGCLens(int *nlocs, int *nfrag, // outputs
		   const int *gcline,const int *gclen,const int *fragments,const int *locslen,const int *sampline, // inputs
		   const int *minlens,const int *maxlens,const int *margin,const int *max_frag_for_loc // params
		   ) {
  
  // Length here is l, the gc-window size. Margin is the a. 
  
  // Intialize counters to 0
  int counters[MAXLEN];
  int i,j,l;
  for (i=0; i< MAXLEN; i++){
    for (j=0; j< MAXLEN; j++){
      nlocs[i+j*MAXLEN] = 0;
      nfrag[i+j*MAXLEN] = 0;
    }
    counters[i] = 0;
  }

  
  // Initialize counters
  const int init_loc = 301;
 
  // Need to prepare the counters at init_loc-1
  // counters[i] refers to a window of size i
  int tmp_sum = 0;
  for (i=0; i<maxlens[0] ; i++){
    // adjust by -1
    tmp_sum = tmp_sum + gcline[init_loc - 1 + margin[0] + i];
    // i+2*margin[0] compensates for second margin
    if (i >= minlens[0]-1) {
      counters[i+1] = tmp_sum;
    }
  }
  //countersPrint(counters,minlens[0], maxlens[0]);

  // loc marks location (of begining of fragment) in chromosome     
  int loc = init_loc;
  int f_ind = 0;
  // f_ind marks indicator of first fagment starting at i in the locs_and_leng list
  int cnt=0;
  int chrom_edge = 2*MAXLEN;

  // Make sure we stop updating before reaching last fragment or end of chromosome
  while( (loc+chrom_edge <= fragments[locslen[0]-1]-1) && (loc+chrom_edge <= gclen[0])) {

    // Main Loop:
    // 'fragments' are in R-coordinates (start from 1)
    // All vectors: gcline, sampline, and loc will be at C-coordinates (start from 0) 
    // loc will be compared to fragments[]-1 


    for (i=minlens[0]; i<=maxlens[0] ; i++){
      // For each counter, remove base immediately outside window (-1), 
      //                   add base immediately inside (i-1)
      counters[i] = counters[i] - gcline[(loc-1)+margin[0]] + gcline[loc + margin[0] + i-1];
      if (counters[i]<0) {
	Rprintf("Error, i:%d, counters[i]:%d, loc: %d, f_ind: %d \n",i, counters[i], loc, f_ind );
	return;
      }
    }
    // Move the fragment indicator
    while( (fragments[f_ind]-1 < loc) && (f_ind<locslen[0]-1) ) { 

      f_ind= f_ind+1;
	
    }
    
    // If this is a sample point, add to both nlocs and to nfrags
    if (sampline[loc]) {
 
      // Count how many fragments at this point
      j = 0;
      //      Rprintf("j: %d loc: %d, f_ind: %d, fragments[f_ind]: %d \n",j, loc, f_ind, fragments[f_ind]);

      while( (fragments[f_ind+j]-1 == loc) && ((j+f_ind)< (locslen[0]-1))  ) {
	j++;
	//	Rprintf("j: %d loc: %d, f_ind: %d, fragments[f_ind]: %d \n",j, loc, f_ind, fragments[f_ind]);
      }
      if (j>max_frag_for_loc[0]) {
	j = max_frag_for_loc[0];
      }
      // for each fragment length add the gc into the location counts
      for (i=minlens[0]; i<=maxlens[0] ; i++){
        nlocs[ i + MAXLEN*counters[i]] = nlocs[i + MAXLEN*counters[i]] + 1;
	nfrag[ i + MAXLEN*counters[i]] = nfrag[i + MAXLEN*counters[i]] + j;
      }
      cnt = cnt + j;
    }	
    // some output that we are making progress
    if ((loc % 1000000) == 0){
      //  Rprintf("%d, %d, %d, %d, %d, %d, %d\n", cnt, loc, f_ind, fragments[f_ind],j, nfrag[600*600-1], nlocs[600*600-1]);
      Rprintf(".");
    }   
    loc = loc + 1;
  }
  Rprintf("Total Fragments: %d", cnt);
}



void fastcount(int *tablex,int *tabley,const int *xvar,const int *yvar,const int *naline, int *varlen){
  // Returns -1 if no xvar
  // Returns count (sum o/f yvar[xvar==x]) 
  for (int i = 0; i < varlen[0]; i++) {
    if (naline[i]) {
      tablex[xvar[i]]++;
      tabley[xvar[i]] += yvar[i];
    }
  }
}
